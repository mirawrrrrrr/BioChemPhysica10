Pixel Apple Sprite Pack
Created and owned by Ascendancy Arcade LLC

---

Thank you for downloading or purchasing this asset pack!
Your support means a lot and helps Ascendancy Arcade LLC continue creating high-quality indie assets.
-----------------------------------------------------------------------------------------------------

ABOUT THIS PACK
This pack contains a collection of clean pixel-art apple sprites including:
• Full apples (Red, Green, Yellow)
• Apple core variants
• A special enchanted apple
• A bonus apple basket icon

These sprites are suitable for:
• 2D games
• Inventory systems
• UI/UX icons
• Retro, cozy, or casual games

---

FILE CONTENTS
• Preview / Screenshot - includes PNG and screenshot of the canvas size.
• Spritesheet – includes Aseprite file
• License.txt – full license terms
• ReadMe.txt – this file

---

GENERAL USAGE
You may freely use and modify these assets in your personal or commercial projects as long as you follow the license terms included in License.txt.

If you enjoy this pack, please consider leaving a rating or donation on Itch.io. Your support helps fund future pixel-art collections and tools by Ascendancy Arcade LLC.

Thank you again for supporting indie creation!
– Ascendancy Arcade LLC
